package hbc.challenge.paintshop;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Tejbir Singh
 *
 */
public class Customer {

	private Map<Integer, String> paintSelection = new HashMap<>();  // key is paint color and value is either G or M

	/**
	 * @return paintSelection
	 */
	public Map<Integer, String> getPaintSelection() {
		return paintSelection;
	}

	/**
	 * @param argPaintSelection Customer paint preferences
	 */
	public void setPaintSelection(final Map<Integer, String> argPaintSelection) {
		this.paintSelection = argPaintSelection;
	}
	
}
