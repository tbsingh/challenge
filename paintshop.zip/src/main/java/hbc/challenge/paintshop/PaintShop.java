package hbc.challenge.paintshop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Tejbir SIngh
 *
 */
public class PaintShop {
	public static void main(String[] args) {

		if (args.length != 1) {
			System.err.println("Usage: java PaintShop <file path>");
			System.exit(1);
		}
		try {
			PaintMixer paintMixer = new PaintMixer();
			File file = new File(args[0]);	
			String finishes = paintMixer.mixPaints(file);
			System.out.println(finishes);
		} catch (FileNotFoundException e) {
			System.err.println("File not found " + args[0]);
			System.exit(2);
		} catch (IOException e) {
			System.err.println("File I/O Error."+e);
			System.exit(3);
		} catch (Exception e) {
			System.err.println("Unknow error."+e);
			System.exit(5);
		}
		System.exit(0);
	}
}
