package hbc.challenge.paintshop;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * @author Tejbir Singh
 *
 */
public class PaintMixer {

	
	private static final String G = "G"; //Gloss
	private static final String NO_SOLUTION_EXISTS = "No solution exists";
	private int colorsCount = 0;
	private	List<Customer> customers = new ArrayList<>();
	private Map<Integer, String> fixedFinish = new HashMap<>();

	/**
	 * Method takes input file as argument and process the  colour mixing.
	 * @param argInputFile
	 * @return colour mixed
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws NumberFormatException
	 */
	public String mixPaints(final File argInputFile) throws Exception, IOException, FileNotFoundException, NumberFormatException {

		readDataFromFile(argInputFile);

		//sort by number of paint choices per customer
		customers =  customers.stream().sorted((c1, c2)->
		Integer.compare(c1.getPaintSelection().size(), c2.getPaintSelection().size())).collect(Collectors.toList());
		for (Customer customer : customers) {			
			if (customer.getPaintSelection().size() == 1) {  //if customer has only one choice it should be fixed
				for(Integer key : customer.getPaintSelection().keySet()){ //loop will run only once
					String thisFinish = customer.getPaintSelection().get(key);
					String fixfinish = fixedFinish.get(key);
					
					if(fixfinish == null || fixfinish.equals(thisFinish)){
						fixedFinish.put(key,thisFinish );  //this needs to be fixed or it's already fixed.
					}
					else{
						return NO_SOLUTION_EXISTS; //means already fixed for other customer - No solution exists
					}
				}
			}
			else {
			    //if customer has more than 1 color choices, 
				Map<Integer,String> paintsToDecide = new HashMap<>();				
				String thisFinish = findPaintForCustomer(customer, paintsToDecide);
				
				if (thisFinish != null) {
					//Customer is already Satisfied
					continue;
				}
				else if (paintsToDecide.isEmpty()) {
					//all choices are in conflict
					return NO_SOLUTION_EXISTS;
				}
					
				String finishToSelect = null;
				Integer colorToSelect = null;
				for (Integer color : paintsToDecide.keySet()) {
					String finish = paintsToDecide.get(color);
					if (finish.equals(G)) {
						finishToSelect = finish;
						colorToSelect=color;
					}
				}
				if(finishToSelect != null && colorToSelect != null){
					fixedFinish.put(colorToSelect, finishToSelect);
				}
				else{ //keep the first element
					Set<Integer> keys= paintsToDecide.keySet();
					for(Integer key : keys){ //get the first color from  paintsToDecide
						colorToSelect = key;
						break;
					}
					finishToSelect = paintsToDecide.get(colorToSelect);
					fixedFinish.put(colorToSelect, finishToSelect);
				}
				
			}
		}
				
		return mapToString();
	}

	/**
	 * @return mixed colours
	 */
	private String mapToString() {
		StringBuilder result = new StringBuilder();
		for(int colorNo=1; colorNo<=colorsCount; colorNo++){
			//check if color is fixed
			String finish = fixedFinish.get(colorNo);
			if (finish == null) {
				// if not in the list make it G as it's cheaper, 
				finish = G;
			}
			if (result.length() > 0) {  //avoid space in beginning
				result.append(" ").append(finish);
			}
			else{
				result.append(finish); 
			}
		}
		return result.toString();
	}

	/** Method finds a paint for a customer
	 * @param customer
	 * @param paintsToDecide
	 * @return color fixed for customer
	 */
	private String findPaintForCustomer(Customer customer, Map<Integer, String> paintsToDecide) {
		for (Integer color : customer.getPaintSelection().keySet()) {
			String fixFinish = fixedFinish.get(color);
			String thisFinish = customer.getPaintSelection().get(color);
			
				if (fixFinish == null) {
					// 'color' is not yet decided
					paintsToDecide.put(color,thisFinish);
				}
				else if (fixFinish.equals(thisFinish)){
					// let's return it!
					return fixFinish;
				}		

		}
		return null;
	}

	/** Reads customer choices from file
	 * @param argFile
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	private void readDataFromFile(final File argFile) throws NumberFormatException, IOException {

		//create a buffer reader to read from file
			BufferedReader br = new BufferedReader(new FileReader(argFile));
			boolean firstLineRead = false;
			String line = null;
			while ((line = br.readLine()) != null) {
				if (!firstLineRead) {
					colorsCount = Integer.parseInt(line.trim()); //numbers of colors are in first line
					firstLineRead = true;
				} else {
					if (line == null || line.equals("")) {
						continue; //ignore blank lines
					}
					Customer customer = readCustomerChoice(line);
					customers.add(customer);
				}
			}
		
	}

	
	/** Method converts a customer line read from file into Customer object
	 * @param customerLine
	 * @return Customer
	 */
	private Customer readCustomerChoice(String customerLine){

		if (customerLine == null || customerLine.equals("")) {
			return null;
		}
		Customer customer = new Customer();
		String[] colorsDetail = customerLine.split(" ");
		for (int i = 0; i < colorsDetail.length; i+=2) { //read color number and finish

			Integer color = Integer.parseInt(colorsDetail[i]);
			String finish= colorsDetail[i+1];
			customer.getPaintSelection().put(color, finish);
		}
		return customer;
	}
	
}
