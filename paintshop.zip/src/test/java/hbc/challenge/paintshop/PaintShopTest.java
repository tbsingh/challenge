package hbc.challenge.paintshop;

import java.io.File;

import org.junit.Test;

import junit.framework.Assert;

public class PaintShopTest {

	@Test
	public void testPaintShop() throws Exception {
		PaintMixer paintMixer = new PaintMixer();

		String paints1 = paintMixer.mixPaints(new File("src/test/resources/test-data/choices-1.data"));
		Assert.assertEquals("G G G G M", paints1);
		
		PaintMixer paintMixer2 = new PaintMixer();
		String paints2 = paintMixer2.mixPaints(new File("src/test/resources/test-data/choices-2.data"));
		Assert.assertEquals("No solution exists", paints2);
		
		PaintMixer paintMixer3 = new PaintMixer();
		String paints3 = paintMixer3.mixPaints(new File("src/test/resources/test-data/choices-3.data"));
		Assert.assertEquals("G M G M G", paints3);
		
		PaintMixer paintMixer4 = new PaintMixer();
		String paints4 = paintMixer4.mixPaints(new File("src/test/resources/test-data/choices-4.data"));
		Assert.assertEquals("M M", paints4);

		
	}

}
